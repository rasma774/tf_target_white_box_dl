#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 11:30:38 2020

@author: rasmus
"""

from keras.models import load_model
import numpy as np
import pandas as pd
import os
import scipy.stats as sts
__author__ = 'Rasmus Magnusson'
__COPYRIGHT__ = 'Rasmus Magnusson, 2020, Linköping'


def get_avg_expression(path='../../data/'):
    df = pd.read_csv(path + 'tf_0.csv').iloc[:,1:]
    df = df.mean()
    return df.values

def get_model_names():
    fnames = [name for name in os.listdir('../') if 'h5' in name ]
    return fnames

def get_disease_fname(path='expression_atlas_diseases_split/'):
    fname = [name for name in os.listdir(path) if 'vs \'normal\'.csv']
    return fname

def build_mats(gnames, DEG):
    p = []
    FE = []
    for NAME in gnames:
        if NAME not in DEG.index:
            p.append(1)
            FE.append(1)
        else:
            val_tmp = DEG.loc[NAME].values
            if not val_tmp.shape == (2,):
                val_tmp = val_tmp.mean(0)
            p.append(val_tmp[0])
            FE.append(2**val_tmp[1])
    p = np.array(p)
    FE = np.array(FE)
    return p, FE

def test_model(targetFE, TF_FE, model):
    base_TF = np.array([get_avg_expression()])
    baseline = model.predict(base_TF)

    change = model.predict(base_TF * TF_FE)
    r, p = sts.spearmanr(targetFE, (change/baseline)[0])
    return r, p

def main():
    tfnames = pd.read_csv('tfnames.txt', header=None).values.T[0]
    gnames = pd.read_csv('gnames.txt', header=None).values.T[0]

    results_model_r = {}
    results_model_p = {}
    
    for DEGname in get_disease_fname():
        print(DEGname)
        DEG = pd.read_csv('expression_atlas_diseases_split/' + DEGname).set_index('Gene Name')
        targetp, targetFE = build_mats(gnames, DEG)
        TFp, TF_FE = build_mats(tfnames, DEG)

        
        res_r = {}
        res_p = {}
        for modelname in get_model_names():
                model = load_model('../' + modelname)
                res_r[modelname], res_p[modelname] = test_model(targetFE, TF_FE, model)
        results_model_r[DEGname] = res_r
        results_model_p[DEGname] = res_p

        pd.DataFrame(results_model_r).to_csv('results_corr.csv')
        pd.DataFrame(results_model_p).to_csv('results_p.csv')

if __name__ == '__main__': 
    main()
